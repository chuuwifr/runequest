@echo off
chcp 65001 >nul
title RuneQuesting FR - Lanceur Local
echo ====================================================
echo  RuneQuesting FR - Demarrage de l application locale
echo ====================================================
echo.
echo Lancement du serveur local sur le port 8080...
echo Ouverture automatique dans votre navigateur...
start http://localhost:8080
python -m http.server 8080
if %ERRORLEVEL% NEQ 0 (
  echo Python non detecte, ouverture directe dans votre navigateur par defaut...
  start index.html
)
pause
