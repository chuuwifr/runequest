#!/bin/bash
cd "$(dirname "$0")"
echo "===================================================="
echo " RuneQuesting FR - Demarrage Local"
echo "===================================================="
echo "Ouverture dans le navigateur..."
which xdg-open > /dev/null && xdg-open http://localhost:8080 || which open > /dev/null && open http://localhost:8080 || echo "Ouvrez http://localhost:8080 dans votre navigateur"
python3 -m http.server 8080 || python -m SimpleHTTPServer 8080
